---
name: Glitch
about: Report unexpected behavior or something doesn't work
title: ''
labels: 'bug'
assignees: 'vinceliuice'

---

<!------------------------------------------------------------------------------
Please provide your system info (distro version, etc.) and of course, the screenshot
------------------------------------------------------------------------------->


